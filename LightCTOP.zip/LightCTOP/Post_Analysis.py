

def Check_ADL_Updates(  ):
    """
    This file checks
    """
    pass






