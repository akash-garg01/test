# -*- coding: utf-8 -*-
"""
Created on Sun May 06 17:00:26 2018

@author: Guodong

https://stackoverflow.com/questions/8931099/quicker-to-os-walk-or-glob
"""







